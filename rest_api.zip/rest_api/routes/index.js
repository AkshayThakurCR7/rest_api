import express from "express";
const router =express.Router();
import {registerController, loginController, userController ,refreshController ,productController} from '../controllers';
import admin from "../middleware/admin";
import auth from '../middleware/auth'


//auth route
router.post('/register', registerController.register)
router.post('/login', loginController.login)
router.get('/me', auth, userController.me)
router.post('/refresh', refreshController.refresh)
router.post('/logout', auth, loginController.logout)

// products routes
router.post('/products',[auth,admin], productController.store)
router.put('/products/:id',[auth,admin], productController.update)
router.delete('/products/:id',[auth,admin], productController.destroy)
router.get('/products', productController.getAllProducts)
router.get('/products/:id', productController.getSingleProduct)

export default router;