import express from "express";
const app = express();
import {APP_PORT , DB_URL} from './config';
import router from './routes';
import errorHandler from './middleware/errorHandler';
import mongoose from "mongoose";
import path from 'path';



global.appRoot = path.resolve(__dirname);
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

mongoose.connect(DB_URL,{useNEWurlparser : true, useunifiedTopology : true})
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error'));
db.once('open',() => {
    console.log("DB Connected succesfully......")
})

app.use('/api',router);
app.use('/uploads', express.static('uploads'))

app.use(errorHandler);

app.listen( APP_PORT,()=>{
    console.log(`Server listen at port ${APP_PORT}`)
});