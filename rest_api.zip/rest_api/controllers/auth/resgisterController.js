import Joi from 'joi'
import CustomErrorHandler from '../../service/CustomErrorHandler';
import { User ,RefreshToken } from '../../models';
import bcrypt from 'bcrypt';
import JwtService from '../../service/JwtService';
import { REFRESH_SECRET } from '../../config';

const registerController={

   async register(req,res,next){
        
      const  registerSchem = Joi.object({
        name : Joi.string().min(3).max(30).required(),
        email : Joi.string().email().required(),
        password : Joi.string().pattern(new RegExp('^[a-zA-Z0-9]{3,30}$')).required(),
        re_password : Joi.ref('password')
        });

        

        const {error} = registerSchem.validate(req.body);

        if(error){
            return next(error)
        }

        // check email exists or not in DB
        try{

        const exists = await User.exists({email :  req.body.email})
        if(exists){
            return next(CustomErrorHandler.alreadyExists("This email already taken"))
        }

        }catch(err){
            return next(err)
        }

        const { name, email, password} = req.body;

         // hash password
         const hashPassword = await bcrypt.hash(password, 10);
                

        // prepare model 
        const user  = new User ({
            name,
            email,
            password : hashPassword
        })
      
        let access_token;
        let refresh_token;
        try {
        const result = await user.save();
            
          access_token =   JwtService.sign({_id:result._id, role:result.role})
          refresh_token =   JwtService.sign({_id:result._id, role:result.role},'1y',REFRESH_SECRET)

          await RefreshToken.create({token : refresh_token})
        } catch (error) {
            return next(error);
        }

        res.json({access_token, refresh_token})
    }
}

export default registerController;